const pdfPath = "pdfexample.pdf";
pdfjsLib.GlobalWorkerOptions.workerSrc =
  "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.worker.min.js";
const pdfjsLib = window["pdfjs-dist/build/pdf"];

// Load the PDF file
pdfjsLib.getDocument(pdfPath).promise.then((pdf) => {
  // Display the first page of the PDF in the viewer
  pdf.getPage(1).then((page) => {
    const scale = 1.5;
    const viewport = page.getViewport({ scale });

    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");
    canvas.width = viewport.width;
    canvas.height = viewport.height;

    const renderContext = {
      canvasContext: context,
      viewport: viewport,
    };

    page.render(renderContext);
    document.getElementById("pdf-viewer").appendChild(canvas);
  });
});

const fs = require("fs");
const productsFilePath = "src/products.txt";
const productsData = fs.readFileSync(productsFilePath, "utf8");
const productsArray = productsData.split("\n").map((line) => line.trim());
let productInfo = [[]];
for (let line of productsArray) {
  if (line) {
    productInfo[productInfo.length - 1].push(line);
  } else {
    productInfo.push([]);
  }
}
let scores = [];
// console.log(productInfo);
// for (let product of productInfo) {
//   console.log(product)
//   score = Number(product[1].split(' '))
//   scores.push(score)
// }
// console.log(scores)

scores = [0.68, 0.23, 0.32, 0.45, 0.12, 0.34, 0.67, 0.89];
