// const { JSDOM } = require("jsdom");
// const fs = require("fs");
// import { Wallet } from "@vechain/sdk-core";
// const wallet = Wallet.generate();
// console.log("Private Key:", wallet.privateKey.toString("hex"));
// console.log("Address:", wallet.getAddress());

// const path = require("path");
// const { window } = new JSDOM();
// global.window = window;
// global.document = window.document;
// global.navigator = window.navigator;
// const scriptFilePath = path.resolve(__dirname, "script.js");
// const scriptContent = fs.readFileSync(scriptFilePath, "utf8");
// eval(scriptContent);

import { Wallet } from "@vechain/sdk-core";
console.log(Wallet);
